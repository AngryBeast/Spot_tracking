#ifndef __KEYBOARD_H
#define __KEYBOARD_H	 


void  KeyBoard_Init(void);

int KeyBoard_scan();

void read_keyBoard(char *p);

#endif